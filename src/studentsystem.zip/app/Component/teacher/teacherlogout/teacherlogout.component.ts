import { Component } from '@angular/core';

@Component({
  selector: 'app-teacherlogout',
  templateUrl: './teacherlogout.component.html',
  styleUrl: './teacherlogout.component.css'
})
export class TeacherlogoutComponent {

}
