import { Component } from '@angular/core';

@Component({
  selector: 'app-teacherassignment',
  templateUrl: './teacherassignment.component.html',
  styleUrl: './teacherassignment.component.css'
})
export class TeacherassignmentComponent {

}
